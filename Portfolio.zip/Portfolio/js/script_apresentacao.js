var typed = new Typed(".texto-multiplo",{strings:["Front-End","Back-End","Database Admin"], typeSpeed: 100,
backSpeed: 100,
backDeley: 1000,
loop: true 
})